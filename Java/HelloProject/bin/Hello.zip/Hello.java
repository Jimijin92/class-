
public class Hello {

	public static void main(String []arg) {
		
		//Ctrl + F11
		System.out.println("�ȳ��ϼ���.");
		//ENCORDING (8로 바꾸기)
		
		}
